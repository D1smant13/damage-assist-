package com.damagegroup.assister.controller;

import com.damagegroup.assister.common.AssistRequest;
import com.damagegroup.assister.service.AssistService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/assist")
public class AssistController {

    private final AssistService assistService;

    public AssistController(AssistService assistService) {
        this.assistService = assistService;
    }

    @PostMapping
    public ResponseEntity<Boolean> x(@RequestBody AssistRequest request) {
        assistService.requestAssist(request);
        return ResponseEntity.ok(true);
    }

}
