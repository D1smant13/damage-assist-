package com.damagegroup.assister.bot.commands;

import com.damagegroup.assister.bot.DiscordBot;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public abstract class Command {

    private final String name;
    @Autowired
    protected DiscordBot bot;

    public Command(@NotNull String name) {
        this.name = name.toLowerCase();
    }

    @PostConstruct
    public void register() {
        bot.getCommandListener().registerCommand(this);
    }

    public String getName() {
        return name;
    }

    public CommandResponse checkArguments(List<String> args) {
        return CommandResponse.SUCCESS;
    }

    public abstract void execute(GuildMessageReceivedEvent event, List<String> args);

    public void register(Map<String, Command> map) {
        map.put(name, this);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || getClass() != other.getClass()) return false;
        Command command = (Command) other;
        return name.equals(command.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }

}
