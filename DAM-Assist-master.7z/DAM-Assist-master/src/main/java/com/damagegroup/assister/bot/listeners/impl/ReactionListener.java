package com.damagegroup.assister.bot.listeners.impl;

import com.damagegroup.assister.bot.listeners.EventListener;
import com.damagegroup.assister.config.DiscordProperties;
import com.damagegroup.assister.service.AssistService;
import net.dv8tion.jda.api.events.message.guild.react.GuildMessageReactionAddEvent;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

@Service
public class ReactionListener extends EventListener {

    private final DiscordProperties discordProperties;
    private final AssistService assistService;

    public ReactionListener(DiscordProperties discordProperties, AssistService assistService) {
        this.discordProperties = discordProperties;
        this.assistService = assistService;
    }

    @Override
    public void onGuildMessageReactionAdd(@NotNull GuildMessageReactionAddEvent event) {
        if (event.getUser().isBot()) return;

        if (event.getReactionEmote().getAsReactionCode().equals(discordProperties.getAssist().getEmote()) &&
                assistService.isRequestMessage(event.getMessageIdLong())) {
            assistService.provideAssist(event.getMessageIdLong(), event.getUser());
        }

    }
}
