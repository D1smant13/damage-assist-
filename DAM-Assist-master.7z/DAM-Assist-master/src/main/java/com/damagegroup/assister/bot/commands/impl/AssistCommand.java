package com.damagegroup.assister.bot.commands.impl;

import com.damagegroup.assister.bot.commands.Command;
import com.damagegroup.assister.bot.commands.CommandResponse;
import com.damagegroup.assister.common.AssistRequest;
import com.damagegroup.assister.common.Utilities;
import com.damagegroup.assister.service.AssistService;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class AssistCommand extends Command {

    private static final Pattern ATTACK_PATTERN = Pattern.compile("https://www\\.torn\\.com/loader\\.php\\?sid=attack&user2ID=(?<id>[0-9]*)");

    @Autowired
    private AssistService assistService;

    public AssistCommand(AssistService assistService) {
        super("assist");

        this.assistService = assistService;
    }

    @Override
    public CommandResponse checkArguments(List<String> args) {
        if (args.size() < 1)
            return new CommandResponse("Please provide a target.");

        String targetStr = args.get(0);
        if (!Utilities.isLong(targetStr)) {
            Matcher matcher = ATTACK_PATTERN.matcher(targetStr);
            if (!matcher.matches())
                return new CommandResponse("Please provide a valid target.");

            args.set(0, matcher.group("id"));
        }

        if (args.size() >= 2) {
            if (!Utilities.isByte(args.get(1)))
                return new CommandResponse("Please provide a valid amount of assists.");
        } else {
            args.add(1, "4");
        }

        return CommandResponse.SUCCESS;
    }

    @Override
    public void execute(GuildMessageReceivedEvent event, List<String> args) {
        event.getMessage().delete().queue();

        long user = Long.parseLong(args.get(0));
        byte amount = Byte.parseByte(args.get(1));

        assistService.requestAssist(new AssistRequest(user, amount, event.getMember()));
    }

}
