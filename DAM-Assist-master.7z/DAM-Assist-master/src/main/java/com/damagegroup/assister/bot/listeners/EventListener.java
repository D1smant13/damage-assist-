package com.damagegroup.assister.bot.listeners;

import com.damagegroup.assister.bot.DiscordBot;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;

public abstract class EventListener extends ListenerAdapter {

    @Autowired
    protected DiscordBot bot;

    @PostConstruct
    public void register() {
        bot.getJda().addEventListener(this);
    }

}
