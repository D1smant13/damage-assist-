package com.damagegroup.assister.model.torn;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TornResponse {

    public Error error;

    public boolean hasError() {
        return error != null;
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Error {

        private byte code;
        private String error;

    }

}
