package com.damagegroup.assister.common;

import lombok.Getter;
import lombok.Setter;

import java.util.concurrent.atomic.AtomicInteger;

@Getter
public class AssistRequest {

    private final AtomicInteger provided = new AtomicInteger();
    @Setter
    private long target;
    @Setter
    private short amount;
    @Setter
    private Object requester;

    public AssistRequest() {
    }

    public AssistRequest(long target, short amount) {
        this.target = target;
        this.amount = amount;
    }

    public AssistRequest(long target, short amount, Object requester) {
        this.target = target;
        this.amount = amount;
        this.requester = requester;
    }

}
