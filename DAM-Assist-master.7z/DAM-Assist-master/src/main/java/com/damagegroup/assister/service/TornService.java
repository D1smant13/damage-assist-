package com.damagegroup.assister.service;

import com.damagegroup.assister.config.TornProperties;
import com.damagegroup.assister.model.TornProfile;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class TornService {

    private final TornProperties tornProperties;

    public TornService(TornProperties tornProperties) {
        this.tornProperties = tornProperties;
    }

    public TornProfile getProfile(long target) {
        return getAPIResponse("user", target, "profile", TornProfile.class);
    }

    private <T> T getAPIResponse(String section, long target, String selections, Class<T> clazz) {
        return WebClient.create(String.format("https://api.torn.com/%s/%s?selections=%s&key=%s", section, target, selections, tornProperties.getKey()))
                .get()
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(clazz)
                .block();
    }

}
