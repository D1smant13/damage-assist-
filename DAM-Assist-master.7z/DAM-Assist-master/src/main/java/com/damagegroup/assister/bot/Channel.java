package com.damagegroup.assister.bot;

public enum Channel {

    ASSIST

}
