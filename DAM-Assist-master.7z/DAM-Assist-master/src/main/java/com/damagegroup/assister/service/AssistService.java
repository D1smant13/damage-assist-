package com.damagegroup.assister.service;

import com.damagegroup.assister.bot.Channel;
import com.damagegroup.assister.bot.DiscordBot;
import com.damagegroup.assister.common.AssistRequest;
import com.damagegroup.assister.config.DiscordProperties;
import com.damagegroup.assister.model.TSSpy;
import com.damagegroup.assister.model.TornProfile;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.MessageBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.User;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class AssistService {

    private final DiscordBot bot;
    private final DiscordProperties discordProperties;
    private final TornService tornService;
    private final TSService tornStatsService;

    private final Map<Long, AssistRequest> requests = new HashMap<>();

    public AssistService(DiscordBot bot, DiscordProperties discordProperties, TornService tornService, TSService tornStatsService) {
        this.bot = bot;
        this.discordProperties = discordProperties;
        this.tornService = tornService;
        this.tornStatsService = tornStatsService;
    }

    public void requestAssist(AssistRequest request) {
        EmbedBuilder embedBuilder = new EmbedBuilder();

        Object requesterObj = request.getRequester();
        if (requesterObj instanceof String)
            embedBuilder.setFooter("Requested by " + requesterObj + ", using the script.");
        else if (requesterObj instanceof Member) {
            Member requester = (Member) requesterObj;
            embedBuilder.setFooter(String.format("Requested by %s#%s", requester.getEffectiveName(), requester.getUser().getDiscriminator()),
                    requester.getUser().getEffectiveAvatarUrl());
        }

        MessageBuilder messageBuilder = new MessageBuilder();

        Role role = bot.getGuild().getRoleById(discordProperties.getAssist().getRole());
        if (role != null)
            messageBuilder.setContent(role.getAsMention());

        TornProfile profile = tornService.getProfile(request.getTarget());
        if (profile != null && !profile.hasError()) {
            TornProfile.Faction faction = profile.getFaction();
            embedBuilder.addField("Target", String.format("%s [%s]", profile.getName(), request.getTarget()), true);

            if (profile.getFaction() != null && profile.hasFaction())
                embedBuilder.addField("Faction", String.format("%s of %s", faction.getPosition(), faction.getName()), true);
        } else {
            embedBuilder.addField("Target", String.valueOf(request.getTarget()), true);
        }

        embedBuilder.addField("Amount", "0/" + String.valueOf(request.getAmount()), true);

        TSSpy spy = tornStatsService.getStatSpy(request.getTarget());
        if (spy != null && spy.isStatus() && spy.getSpy() != null && spy.getSpy().isStatus()) {
            TSSpy.Spy data = spy.getSpy();

            embedBuilder.addField(String.format("Stat Spy (%s)", data.getDifference()), data.toMarkdown(), false);
        }

        bot.getTextChannel(Channel.ASSIST)
                .sendMessage(messageBuilder
                        .setEmbed(embedBuilder.build())
                        .build())
                .queue(message -> {
                    requests.put(message.getIdLong(), request);

                    message.addReaction(discordProperties.getAssist().getEmote()).queue();
                });
    }

    public void provideAssist(long messageId, User user) {
        AssistRequest request = requests.get(messageId);

        if (request.getProvided().get() >= request.getAmount())
            return;

        user.openPrivateChannel().queue(channel -> channel.sendMessage(new MessageBuilder()
                .setContent(String.format("https://www.torn.com/loader.php?sid=attack&user2ID=%s", request.getTarget()))
                .build())
                .queue());

        if (request.getProvided().incrementAndGet() >= request.getAmount())
            closeAssist(messageId);
        else {
            bot.getTextChannel(Channel.ASSIST).retrieveMessageById(messageId).queue(message -> {
                EmbedBuilder builder = new EmbedBuilder(message.getEmbeds().get(0));

                MessageEmbed.Field field = builder.getFields().stream().filter(f -> f.getName() != null && f.getName().equals("Amount")).findFirst().orElse(null);
                builder.getFields().set(builder.getFields().indexOf(field), new MessageEmbed.Field("Amount", request.getProvided().get() + "/" + request.getAmount(), true));

                bot.getTextChannel(Channel.ASSIST).editMessageById(messageId, builder.build()).queue();
            });
        }
    }

    public void closeAssist(long messageId) {
        var message = new MessageBuilder().setContent("Fulfilled").build();

        bot.getTextChannel(Channel.ASSIST).editMessageById(messageId, message)
                .override(true)
                .queue(msg -> new Thread(() -> {
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    msg.delete().queue();
                }).start());
        bot.getTextChannel(Channel.ASSIST).clearReactionsById(messageId).queue();
    }

    public boolean isRequestMessage(long id) {
        return requests.containsKey(id);
    }

}
