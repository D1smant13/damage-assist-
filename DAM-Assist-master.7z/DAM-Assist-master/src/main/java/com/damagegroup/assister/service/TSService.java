package com.damagegroup.assister.service;

import com.damagegroup.assister.config.TornProperties;
import com.damagegroup.assister.model.TSSpy;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class TSService {

    private final TornProperties tornProperties;

    public TSService(TornProperties tornProperties) {
        this.tornProperties = tornProperties;
    }

    public TSSpy getStatSpy(long target) {
        return WebClient.create(String.format("https://beta.tornstats.com/api/v1/%s/spy/%s", tornProperties.getKey(), target))
                .get()
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(TSSpy.class)
                .block();
    }

}
