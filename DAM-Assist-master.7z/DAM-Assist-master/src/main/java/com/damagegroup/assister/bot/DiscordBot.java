package com.damagegroup.assister.bot;

import com.damagegroup.assister.bot.listeners.CommandListener;
import com.damagegroup.assister.config.DiscordProperties;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.utils.cache.CacheFlag;
import org.springframework.stereotype.Service;

import javax.security.auth.login.LoginException;

@Service
public class DiscordBot {

    private final CommandListener commandListener;
    private final DiscordProperties discordProperties;

    private JDA jda;

    public DiscordBot(CommandListener commandListener, DiscordProperties discordProperties) {
        this.commandListener = commandListener;
        this.discordProperties = discordProperties;

        try {
            jda = JDABuilder.createDefault(discordProperties.getToken())
                    .setActivity(Activity.playing("Torn"))
                    .disableCache(CacheFlag.ACTIVITY, CacheFlag.EMOTE, CacheFlag.EMOTE)
                    .addEventListeners(commandListener)
                    .build()
                    .awaitReady();
        } catch (LoginException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public JDA getJda() {
        return jda;
    }

    public CommandListener getCommandListener() {
        return commandListener;
    }

    public Guild getGuild() {
        return jda.getGuildById(discordProperties.getGuild());
    }

    public TextChannel getTextChannel(Channel channel) {
        long id;
        switch (channel) {
            case ASSIST:
                id = discordProperties.getAssist().getChannel();
                break;
            default:
                throw new IllegalArgumentException("Unrecognized channel.");
        }

        return getGuild().getTextChannelById(id);
    }

}
