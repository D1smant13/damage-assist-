package com.damagegroup.assister.config;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Getter
@ConfigurationProperties("discord")
public class DiscordProperties {

    private final AssistProperties assist = new AssistProperties();
    @Setter
    private String token;
    @Setter
    private String prefix;
    @Setter
    private long guild;

    @Data
    public static class AssistProperties {

        private long channel;
        private String emote;
        private long role;

    }

}
