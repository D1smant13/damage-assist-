package com.damagegroup.assister.bot.commands;

public class CommandResponse {

    public static final CommandResponse SUCCESS = new CommandResponse();

    private final boolean success;
    private final String message;

    private CommandResponse(boolean success, String message) {
        this.success = success;
        this.message = message;
    }

    public CommandResponse(String message) {
        this(false, message);
    }

    private CommandResponse() {
        this(true, null);
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

}
