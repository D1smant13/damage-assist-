package com.damagegroup.assister.model;

import lombok.Data;

import java.util.Locale;

@Data
public class TSSpy {

    private boolean status;
    private String message;
    private Spy spy;

    @Data
    public static class Spy {

        private boolean status;
        private String message;

        private String type;
        private String difference;
        private long total;
        private long strength;
        private long defense;
        private long speed;
        private long dexterity;

        @SuppressWarnings("unused")
        public void setTotal(String total) {
            try {
                this.total = Long.parseLong(total);
            } catch (NumberFormatException e) {
                this.total = -1;
            }

        }

        @SuppressWarnings("unused")
        public void setStrength(String strength) {
            try {
                this.strength = Long.parseLong(strength);
            } catch (NumberFormatException e) {
                this.strength = -1;
            }
        }

        @SuppressWarnings("unused")
        public void setDefense(String defense) {
            try {
                this.defense = Long.parseLong(defense);
            } catch (NumberFormatException e) {
                this.defense = -1;
            }
        }

        @SuppressWarnings("unused")
        public void setSpeed(String speed) {
            try {
                this.speed = Long.parseLong(speed);
            } catch (NumberFormatException e) {
                this.speed = -1;
            }
        }

        @SuppressWarnings("unused")
        public void setDexterity(String dexterity) {
            try {
                this.dexterity = Long.parseLong(dexterity);
            } catch (NumberFormatException e) {
                this.total = -1;
            }
        }

        public String toMarkdown() {
            long length = total != -1 ? String.format("%,d", total).length() :
                    getLength(getLength(getLength(getLength(0, strength), defense), speed), dexterity);

            final String numberFormat = "%," + length + "d";
            final String stringFormat = "%" + length + "s";

            String builder = "```" + "Strength:  " + (strength != -1 ? numberFormat : stringFormat) + "%n" +
                    "Defense:   " + (defense != -1 ? numberFormat : stringFormat) + "%n" +
                    "Speed:     " + (speed != -1 ? numberFormat : stringFormat) + "%n" +
                    "Dexterity: " + (dexterity != -1 ? numberFormat : stringFormat) + "%n" +
                    "Total:     " + (total != -1 ? numberFormat : stringFormat) +
                    "```";
            return String.format(Locale.ENGLISH,
                    builder,
                    strength != -1 ? strength : "N/A",
                    defense != -1 ? defense : "N/A",
                    speed != -1 ? speed : "N/A",
                    dexterity != -1 ? dexterity : "N/A",
                    total != -1 ? total : "N/A");
        }

        private long getLength(long length, long stat) {
            if (stat != -1) {
                int len = String.format("%,d", stat).length();
                if (len > length) length = len;
            }
            return length;
        }


    }

}
