package com.damagegroup.assister.model;

import com.damagegroup.assister.model.torn.TornResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TornProfile extends TornResponse {

    public String name;
    public Faction faction;

    public boolean hasFaction() {
        return !faction.name.equals("None");
    }

    @Data
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class Faction {

        @JsonProperty("faction_name")
        public String name;
        public String position;

    }

}
