package com.damagegroup.assister;

import com.damagegroup.assister.config.DiscordProperties;
import com.damagegroup.assister.config.TornProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties({DiscordProperties.class, TornProperties.class})
public class AssisterApplication {

    public static void main(String[] args) {
        SpringApplication.run(AssisterApplication.class, args);
    }

}
