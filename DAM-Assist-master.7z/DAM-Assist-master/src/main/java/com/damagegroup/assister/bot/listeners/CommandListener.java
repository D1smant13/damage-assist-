package com.damagegroup.assister.bot.listeners;

import com.damagegroup.assister.bot.commands.Command;
import com.damagegroup.assister.bot.commands.CommandResponse;
import com.damagegroup.assister.config.DiscordProperties;
import net.dv8tion.jda.api.MessageBuilder;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class CommandListener extends ListenerAdapter {

    private final DiscordProperties discordProperties;

    private final Map<String, Command> commands = new HashMap<>();

    public CommandListener(DiscordProperties discordProperties) {
        this.discordProperties = discordProperties;
    }

    public void registerCommand(Command command) {
        command.register(commands);
    }

    @Override
    public void onGuildMessageReceived(@NotNull GuildMessageReceivedEvent event) {
        if (event.getAuthor().isBot()) return;

        final String content = event.getMessage().getContentStripped();
        if (content.startsWith(discordProperties.getPrefix())) {
            final String cmd = content.split(" ")[0].substring(1).toLowerCase();
            if (!commands.containsKey(cmd)) return;

            Command command = commands.get(cmd);

            final List<String> args = new ArrayList<>(Arrays.asList(content.split(" ")));
            args.remove(0);

            CommandResponse argumentResponse = command.checkArguments(args);
            if (!argumentResponse.isSuccess()) {
                event.getChannel().sendMessage(new MessageBuilder()
                        .setContent(argumentResponse.getMessage())
                        .build()).queue();
                return;
            }

            command.execute(event, args);
        }

    }

}
