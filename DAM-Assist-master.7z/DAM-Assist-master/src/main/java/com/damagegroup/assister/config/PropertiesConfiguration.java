package com.damagegroup.assister.config;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static java.util.Arrays.stream;

@Component
public class PropertiesConfiguration extends PropertySourcesPlaceholderConfigurer implements EnvironmentAware, InitializingBean {

    private String[] locations;

    @Autowired
    private ResourceLoader loader;
    private Environment environment;

    @Override
    public void setEnvironment(@NotNull Environment environment) {
        super.setEnvironment(environment);

        this.environment = environment;
    }

    @Override
    public void afterPropertiesSet() {
        MutablePropertySources propertySources = ((ConfigurableEnvironment) environment).getPropertySources();

        propertySources
                .stream()
                .filter(source -> source.containsProperty("application.properties.locations"))
                .forEach(source -> stream(((String) Objects.requireNonNull(source.getProperty("application.properties.locations"))).split(","))
                        .forEach(filename -> loadProperties(filename).forEach(propertySources::addFirst)));
    }

    private List<PropertySource<?>> loadProperties(final String filename) {
        YamlPropertySourceLoader loader = new YamlPropertySourceLoader();
        try {
            final Resource[] possiblePropertiesResources = ResourcePatternUtils.getResourcePatternResolver(this.loader).getResources(filename);

            return stream(possiblePropertiesResources)
                    .filter(Resource::exists)
                    .map(resource1 -> {
                        try {
                            return loader.load(resource1.getFilename(), resource1);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    })
                    .flatMap(Collection::stream)
                    .collect(Collectors.toList());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}